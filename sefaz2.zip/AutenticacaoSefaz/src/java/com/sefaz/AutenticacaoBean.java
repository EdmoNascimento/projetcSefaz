package com.sefaz;

import javax.ejb.Stateless;

@Stateless
public class AutenticacaoBean implements autenticacaoRemote{

   @Override
   public boolean autenticar(String login, String senha){
      return "admin".equals(login) && "admin".equals(senha);
   }
   
}
