package com.sefaz;

import javax.ejb.Remote;

@Remote
public interface autenticacaoRemote {
    public boolean autenticar(String login, String senha);
}
